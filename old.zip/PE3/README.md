To try the scanner:

```
make scanner
cat vsl_programs/euclid.vsl | ./scanner
```
